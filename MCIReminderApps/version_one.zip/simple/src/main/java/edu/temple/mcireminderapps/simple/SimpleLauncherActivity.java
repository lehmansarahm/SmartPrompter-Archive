package edu.temple.mcireminderapps.simple;

import android.content.Intent;
import android.os.Bundle;

import edu.temple.mci_res_lib.activities.BaseReminderActivity;
import edu.temple.mci_res_lib.activities.ReminderCountActivity;
import edu.temple.mci_res_lib.activities.ReminderStatusActivity;
import edu.temple.mci_res_lib.managers.MCIPreferenceManager;

public class SimpleLauncherActivity extends BaseReminderActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_launcher);
        verifySchedulePrefs();

        Intent intent;
        if (schedPrefs.reminderCount == 0) intent = new Intent(this, ReminderCountActivity.class);
        else intent = new Intent(this, ReminderStatusActivity.class);

        intent.putExtra(MCIPreferenceManager.EXECUTION_MODE,
                MCIPreferenceManager.SchedulePrefs.EXEC_MODES.Basic.toString());
        startActivity(intent);
        finish();
    }

}