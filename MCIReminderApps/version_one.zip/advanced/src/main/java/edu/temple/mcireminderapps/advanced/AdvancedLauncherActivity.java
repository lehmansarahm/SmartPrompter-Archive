package edu.temple.mcireminderapps.advanced;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;

import edu.temple.mci_res_lib.activities.BaseReminderActivity;
import edu.temple.mci_res_lib.activities.ReminderCountActivity;
import edu.temple.mci_res_lib.activities.ReminderStatusActivity;
import edu.temple.mci_res_lib.managers.MCIPreferenceManager;
import edu.temple.mci_res_lib.utils.Constants;
import edu.temple.mci_res_lib.utils.PermissionUtils;

public class AdvancedLauncherActivity extends BaseReminderActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_launcher);
        verifySchedulePrefs();

        // make sure we have the appropriate permissions before moving forward
        boolean canUseCamera = PermissionUtils.getPermission(this, Manifest.permission.CAMERA,
                Constants.PERMISSION_FLAG_CAMERA);
        boolean canReadExternal = PermissionUtils.getPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE,
                Constants.PERMISSION_FLAG_READ_EXTERNAL_STORAGE);
        boolean canWriteExternal = PermissionUtils.getPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Constants.PERMISSION_FLAG_WRITE_EXTERNAL_STORAGE);

        // only proceed with rest of app if we have all necessary permissions
        if (canUseCamera && canReadExternal && canWriteExternal) {
            Intent intent;
            if (schedPrefs.reminderCount == 0)
                intent = new Intent(this, ReminderCountActivity.class);
            else intent = new Intent(this, ReminderStatusActivity.class);

            intent.putExtra(MCIPreferenceManager.EXECUTION_MODE,
                    MCIPreferenceManager.SchedulePrefs.EXEC_MODES.Advanced.toString());
            startActivity(intent);
            finish();
        }
    }

}