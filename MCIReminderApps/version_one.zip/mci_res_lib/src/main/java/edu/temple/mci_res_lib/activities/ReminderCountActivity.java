package edu.temple.mci_res_lib.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import edu.temple.mci_res_lib.R;
import edu.temple.mci_res_lib.managers.MCIPreferenceManager;
import edu.temple.mci_res_lib.utils.Constants;

public class ReminderCountActivity extends BaseReminderActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_count);
        Log.i(Constants.LOG_TAG, "LAUNCHING REMINDER COUNT ACTIVITY\n\n");

        final EditText remCount = findViewById(R.id.remCount);
        final Button continueButton = findViewById(R.id.continueButton);

        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ReminderCountActivity.this, ReminderTimeActivity.class);
                intent.putExtra(MCIPreferenceManager.REMINDER_COUNT,
                        Integer.parseInt(remCount.getText().toString()));
                intent.putExtra(MCIPreferenceManager.EXECUTION_MODE,
                        schedPrefs.executionMode.toString());
                startActivity(intent);
                finish();
            }
        });
    }

}