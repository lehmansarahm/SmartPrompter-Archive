package edu.temple.mci_res_lib.managers;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.util.Calendar;

import edu.temple.mci_res_lib.receivers.ReminderReceiver;
import edu.temple.mci_res_lib.receivers.SingleAlarmReceiver;
import edu.temple.mci_res_lib.utils.Constants;
import edu.temple.mci_res_lib.utils.DateUtils;

public class MCIAlarmManager {

    private static Context context;
    private static AlarmManager alarmMgr;

    public static final int REMINDER_REQUEST_CODE = 2204;

    // could be extended to repeating alarms, or different pending intent types (activities, etc.)
    public static void startSingleBroadcastAlarm(Context newContext, Calendar alarmTime, int requestCode) {
        init(newContext, alarmTime);
        alarmMgr.set(AlarmManager.RTC_WAKEUP, alarmTime.getTimeInMillis(), getSingleBroadcastPI(requestCode));
    }

    public static void startReminderAlarm(Context newContext) {
        Calendar reminderTime = DateUtils.getReminderTime();
        init(newContext, reminderTime);
        alarmMgr.set(AlarmManager.RTC_WAKEUP, reminderTime.getTimeInMillis(), getReminderPI());
    }

    private static void init(Context newContext, Calendar alarmTime) {
        Log.i(Constants.LOG_TAG, "Establishing new single-shot alarm..."
                + "\nCurrent time (ms): " + Calendar.getInstance().getTimeInMillis()
                + "\nAlarm time (ms): " + alarmTime.getTimeInMillis()
                + "\nInterval (ms): " + (alarmTime.getTimeInMillis() - Calendar.getInstance().getTimeInMillis()));

        context = newContext.getApplicationContext();
        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    }

    private static PendingIntent getSingleBroadcastPI(int requestCode) {
        Intent intent = new Intent(context, SingleAlarmReceiver.class);
        PendingIntent newPI = PendingIntent.getBroadcast(context, requestCode,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return newPI;
    }

    private static PendingIntent getReminderPI() {
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent newPI = PendingIntent.getBroadcast(context, REMINDER_REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return newPI;
    }

}