package edu.temple.mci_res_lib.notifiers;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import edu.temple.mci_res_lib.R;
import edu.temple.mci_res_lib.activities.BaseReminderActivity;
import edu.temple.mci_res_lib.activities.CameraViewerActivity;
import edu.temple.mci_res_lib.managers.MCIAlarmManager;
import edu.temple.mci_res_lib.managers.MCINotificationManager;
import edu.temple.mci_res_lib.utils.Constants;

public class SingleAlarmAdvancedNotifier extends BaseReminderActivity {

    private MCINotificationManager notiManager = new MCINotificationManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti_adv_conf);

        Log.d(Constants.LOG_TAG, "Executing advanced single alarm!  Setting alarm-outstanding flag and calling up notification dialog...");
        MCIAlarmManager.startReminderAlarm(SingleAlarmAdvancedNotifier.this);
        addOutstandingAlarm();

        notiManager.playNotificationTone(this, Constants.DEFAULT_RINGTONE_TIME_MS);
        notiManager.displayNotiDialog(this, Constants.REMINDER_TITLE, Constants.ALERT_TEXT);

        final Button closeButton = findViewById(R.id.takePictureButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SingleAlarmAdvancedNotifier.this, CameraViewerActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

}