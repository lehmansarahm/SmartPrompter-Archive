package edu.temple.mci_res_lib.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import edu.temple.mci_res_lib.R;

public class TimeDisplayListAdapter extends BaseTimeAdapter {

    public TimeDisplayListAdapter(Activity parentActivity, int layoutID, ArrayList<String> times) {
        this.parentActivity = parentActivity;
        this.layoutID = layoutID;
        this.reminderCount = times.size();
        this.reminderTimes = (ArrayList<String>)times.clone();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = parentActivity.getLayoutInflater();
            convertView = inflater.inflate(layoutID, null);

            holder = new ViewHolder();
            holder.timeLabel = convertView.findViewById(R.id.timeLabel);
            holder.timeValue = convertView.findViewById(R.id.timeValue);
            convertView.setTag(holder);
        }
        else holder = (ViewHolder) convertView.getTag();

        holder.ref = position;
        holder.timeLabel.setText(String.format("Reminder Time %d:", (position + 1)));
        holder.timeValue.setText(reminderTimes.get(position));

        return convertView;
    }

    private class ViewHolder {
        TextView timeLabel;
        TextView timeValue;
        int ref;
    }

}