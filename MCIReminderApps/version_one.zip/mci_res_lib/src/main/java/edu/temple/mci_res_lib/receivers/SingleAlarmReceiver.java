package edu.temple.mci_res_lib.receivers;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import edu.temple.mci_res_lib.managers.MCIPreferenceManager;
import edu.temple.mci_res_lib.notifiers.SingleAlarmAdvancedNotifier;
import edu.temple.mci_res_lib.notifiers.SingleAlarmSimpleNotifier;
import edu.temple.mci_res_lib.utils.Constants;

public class SingleAlarmReceiver extends BaseBroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(Constants.LOG_TAG, "Single alarm receiver activated!  Attempting to retrieve schedule preferences.");
        MCIPreferenceManager.SchedulePrefs prefs = MCIPreferenceManager.getSchedulePrefs(context, intent);
        Log.d(Constants.LOG_TAG, "Preferences retrieved!  Execution mode: " + prefs.executionMode);

        if (prefs.executionMode.equals(MCIPreferenceManager.SchedulePrefs.EXEC_MODES.Basic))
            executeNotifier(context, SingleAlarmSimpleNotifier.class);
        else if (prefs.executionMode.equals(MCIPreferenceManager.SchedulePrefs.EXEC_MODES.Advanced))
            executeNotifier(context, SingleAlarmAdvancedNotifier.class);
    }

}