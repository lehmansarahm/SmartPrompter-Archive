package edu.temple.mci_res_lib.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BaseBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // do nothing ... extending classes will override
    }

    protected void executeNotifier(Context context, Class<?> notifierClass) {
        Intent newIntent = new Intent(context, notifierClass);
        newIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(newIntent);
    }

}
