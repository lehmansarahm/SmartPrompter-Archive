package edu.temple.mci_res_lib.receivers;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import edu.temple.mci_res_lib.managers.MCIPreferenceManager;
import edu.temple.mci_res_lib.notifiers.SingleAlarmAdvancedNotifier;
import edu.temple.mci_res_lib.utils.Constants;

public class ReminderReceiver extends BaseBroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(Constants.LOG_TAG, "Alarm reminder activated!  Provide alarm instruction screen.");
        MCIPreferenceManager.SchedulePrefs prefs = MCIPreferenceManager.getSchedulePrefs(context, intent);

        if (prefs.outstandingAlarmCount >= Constants.OUTSTANDING_ALARM_LIMIT) {
            Log.d(Constants.LOG_TAG, "Reached limit of alarm reminders.  Cancelling this alarm."
                    + "\n... Future alarms will still execute.");
            prefs.outstandingAlarmCount = 0;
            MCIPreferenceManager.saveSchedulePrefs(context, prefs);
            return;
        }

        if (prefs.outstandingAlarmCount > 0)
            executeNotifier(context, SingleAlarmAdvancedNotifier.class);
    }

}