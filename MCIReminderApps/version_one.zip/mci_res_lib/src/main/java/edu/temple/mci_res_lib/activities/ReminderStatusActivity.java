package edu.temple.mci_res_lib.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import edu.temple.mci_res_lib.R;
import edu.temple.mci_res_lib.adapters.TimeDisplayListAdapter;
import edu.temple.mci_res_lib.utils.Constants;

public class ReminderStatusActivity extends BaseReminderActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_status);
        Log.i(Constants.LOG_TAG, "LAUNCHING REMINDER STATUS ACTIVITY\n\n");

        final TextView header = findViewById(R.id.header);
        header.setText(schedPrefs.outstandingAlarmCount > 0
                ? "There are alarms currently outstanding!"
                : "A reminder sequence is currently in progress.");

        final TextView instructions = findViewById(R.id.instructions);
        instructions.setText("Reminders are set to execute at the following times.  Please use "
                + "the 'Reset' button below to cancel the current sequence and start a new one.");

        final TimeDisplayListAdapter adapter = new TimeDisplayListAdapter(ReminderStatusActivity.this,
                R.layout.time_display_row, schedPrefs.reminderTimes);
        ListView listView = findViewById(R.id.listViewMain);
        listView.setAdapter(adapter);

        final Button resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(Constants.LOG_TAG, "RESETTING CURRENT REMINDER SCHEDULE\n\n");
                removeOutstandingAlarm(true);

                Log.i(Constants.LOG_TAG, "LAUNCHING NEXT ACTIVITY\n\n");
                Intent intent = new Intent(ReminderStatusActivity.this, ReminderCountActivity.class);
                startActivity(intent);
                finish();
            }
        });

        final Button closeButton = findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}