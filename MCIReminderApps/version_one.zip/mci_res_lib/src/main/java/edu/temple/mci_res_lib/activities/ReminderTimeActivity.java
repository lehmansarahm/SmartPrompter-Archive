package edu.temple.mci_res_lib.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;

import edu.temple.mci_res_lib.R;
import edu.temple.mci_res_lib.adapters.TimePickerListAdapter;
import edu.temple.mci_res_lib.managers.MCIAlarmManager;
import edu.temple.mci_res_lib.managers.MCIPreferenceManager;
import edu.temple.mci_res_lib.utils.Constants;
import edu.temple.mci_res_lib.utils.DateUtils;

public class ReminderTimeActivity extends BaseReminderActivity {

    private static final String TIME_HEADER = "You have requested:\n%d reminders.";
    private static final String TIME_INSTRUCTIONS = "Please enter the times at which you would like these reminders to execute.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_time);
        Log.i(Constants.LOG_TAG, "LAUNCHING REMINDER TIME ACTIVITY\n\n");
        schedPrefs.reminderCount = getIntent().getIntExtra(MCIPreferenceManager.REMINDER_COUNT, 0);

        final TextView header = findViewById(R.id.header);
        header.setText(String.format(TIME_HEADER, schedPrefs.reminderCount));

        final TextView instructions = findViewById(R.id.instructions);
        instructions.setText(TIME_INSTRUCTIONS);

        final TimePickerListAdapter adapter = new TimePickerListAdapter(ReminderTimeActivity.this,
                R.layout.time_picker_row, schedPrefs.reminderCount);
        ListView listView = findViewById(R.id.listViewMain);
        listView.setAdapter(adapter);

        final Button continueButton = findViewById(R.id.continueButton);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<Calendar> alarmTimes = getAlarmTimes(adapter);
                for (int i = 0; i < alarmTimes.size(); i++)
                    MCIAlarmManager.startSingleBroadcastAlarm(ReminderTimeActivity.this, alarmTimes.get(i), i);

                Intent intent = new Intent(ReminderTimeActivity.this, ReminderStatusActivity.class);
                intent.putExtra(MCIPreferenceManager.REMINDER_COUNT, schedPrefs.reminderCount);
                intent.putExtra(MCIPreferenceManager.REMINDER_TIMES, schedPrefs.reminderTimes);
                intent.putExtra(MCIPreferenceManager.EXECUTION_MODE, schedPrefs.executionMode.toString());

                saveSchedulePrefs(intent);
                startActivity(intent);
                finish();
            }
        });
    }

    private ArrayList<Calendar> getAlarmTimes(TimePickerListAdapter adapter) {
        ArrayList<Calendar> parsedReminderTimes = new ArrayList<>();
        schedPrefs.reminderTimes = new ArrayList<>();
        String reminderTime;

        for (int i = 0; i < schedPrefs.reminderCount; i++) {
            reminderTime = adapter.getItem(i).toString();
            try {
                Calendar parsedReminderTime = DateUtils.parseTimeString(reminderTime, true);
                String displayableReminderTime = DateUtils.getDisplayString(parsedReminderTime);
                Log.d(Constants.LOG_TAG, "Processing new alarm time..."
                        + "\nUser provided time: " + reminderTime
                        + "\nSystem parsed time: " + displayableReminderTime);

                schedPrefs.reminderTimes.add(displayableReminderTime);
                parsedReminderTimes.add(parsedReminderTime);
            } catch (ParseException ex) {
                Log.e(Constants.LOG_TAG, "Attempting to import new alarm times from list view..."
                        + "\nCould not parse calendar object for alarm time: " + reminderTime);
            }
        }

        return parsedReminderTimes;
    }

}