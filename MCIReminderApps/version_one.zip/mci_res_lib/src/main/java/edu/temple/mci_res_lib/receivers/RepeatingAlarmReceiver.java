package edu.temple.mci_res_lib.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import edu.temple.mci_res_lib.managers.MCINotificationManager;
import edu.temple.mci_res_lib.utils.Constants;

public class RepeatingAlarmReceiver extends BroadcastReceiver {

    private MCINotificationManager notiManager = new MCINotificationManager();
    private static int count = 1;

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(Constants.LOG_TAG, "Broadcast received!  Processing reminder.");
        notiManager.playNotificationTone(context, Constants.DEFAULT_RINGTONE_TIME_MS);
        notiManager.displayNotification(context, Constants.REMINDER_TITLE,
                Constants.INTERVAL_TEXT + count, Constants.REMINDER_ID);
        count++;
    }

}