package edu.temple.mci_res_lib.notifiers;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import edu.temple.mci_res_lib.R;
import edu.temple.mci_res_lib.managers.MCINotificationManager;
import edu.temple.mci_res_lib.utils.Constants;

public class SingleAlarmSimpleNotifier extends Activity {

    private MCINotificationManager notiManager = new MCINotificationManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti_simple_conf);

        Log.d(Constants.LOG_TAG, "Executing simple single alarm!  Calling up notification display activity.");
        notiManager.playNotificationTone(this, Constants.DEFAULT_RINGTONE_TIME_MS);
        notiManager.displayNotiDialog(this, Constants.REMINDER_TITLE, Constants.ALERT_TEXT);

        final Button closeButton = findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}