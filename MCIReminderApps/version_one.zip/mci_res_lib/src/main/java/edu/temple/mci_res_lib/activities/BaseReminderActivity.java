package edu.temple.mci_res_lib.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.ArrayList;

import edu.temple.mci_res_lib.managers.MCIPreferenceManager;
import edu.temple.mci_res_lib.managers.MCIPreferenceManager.SchedulePrefs;
import edu.temple.mci_res_lib.utils.Constants;

public class BaseReminderActivity extends AppCompatActivity {

    protected MCIPreferenceManager preferenceManager = new MCIPreferenceManager();
    protected SchedulePrefs schedPrefs = new SchedulePrefs();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        schedPrefs = preferenceManager.getSchedulePrefs(this, getIntent());
    }

    protected void verifySchedulePrefs() {
        preferenceManager.verifySchedulePrefs(this, schedPrefs);
    }

    protected void saveSchedulePrefs(Intent intent) {
        preferenceManager.saveSchedulePrefs(this, intent);
    }

    protected void addOutstandingAlarm() {
        schedPrefs.outstandingAlarmCount++;
        preferenceManager.saveSchedulePrefs(this, schedPrefs);
    }

    protected void removeOutstandingAlarm(boolean cancelAll) {
        Log.i(Constants.LOG_TAG, "Cancelling any outstanding alarms.  Are any alarms currently outstanding?  "
                + (schedPrefs.outstandingAlarmCount > 0));
        schedPrefs.outstandingAlarmCount = 0;

        if (cancelAll) {
            Log.i(Constants.LOG_TAG, "Cancelling all remaining alarms.  Current alarm count: "
                    + schedPrefs.reminderCount);
            schedPrefs.reminderCount = 0;
            schedPrefs.reminderTimes = new ArrayList<>();
        }

        Log.i(Constants.LOG_TAG, "Keeping current exec mode: " + schedPrefs.executionMode);
        preferenceManager.saveSchedulePrefs(this, schedPrefs);
    }

}