package edu.temple.mci_res_lib.managers;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;

import edu.temple.mci_res_lib.R;

public class MCINotificationManager {

    public void playNotificationTone(Context context, long playTimeMs) {
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            final Ringtone rt = RingtoneManager.getRingtone(context, notification);
            rt.play();

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { rt.stop(); }
            }, playTimeMs);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void displayNotiDialog(final Context context, String title, String text) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
                .setMessage(text)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .setIcon(R.drawable.ic_stat_access_alarm);
        builder.show();
    }

    public void displayNotification(Context context, String title, String text, int id) {
        displayNotification(context, title, text, id, null);
    }

    public void displayNotification(Context context, String title, String text, int id, Class<?> cls) {
        Notification.Builder notiBuilder = new Notification.Builder(context)
                .setTicker(title)
                .setContentTitle(title)
                .setContentText(text)
                .setFullScreenIntent(null, true)
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.ic_stat_access_alarm);

        if (cls != null) {
            Intent intent = new Intent(context, cls);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pIntent = PendingIntent.getActivity(context, 0, intent, 0);
            notiBuilder.setContentIntent(pIntent);
        }

        Notification noti = notiBuilder.build();
        if (cls != null) noti.flags |= Notification.FLAG_AUTO_CANCEL;

        NotificationManager notiMgr =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notiMgr.notify(id, noti);
    }

}