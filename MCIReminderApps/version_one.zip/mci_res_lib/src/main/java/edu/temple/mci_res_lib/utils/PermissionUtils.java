package edu.temple.mci_res_lib.utils;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

public class PermissionUtils {

    public static boolean getPermission(Activity context, String permission, int permissionFlag) {
        if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
            Log.i(Constants.LOG_TAG, "Insufficient permission to perform action: " + permission);
            ActivityCompat.requestPermissions(context, new String[] { permission }, permissionFlag);

            boolean hasPermission = (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED);
            Log.i(Constants.LOG_TAG, "Able to obtain permission after explicit request?  " + hasPermission);
            return hasPermission;
        }
        else Log.i(Constants.LOG_TAG, "Permission already granted for action: " + permission);
        return true;
    }

}