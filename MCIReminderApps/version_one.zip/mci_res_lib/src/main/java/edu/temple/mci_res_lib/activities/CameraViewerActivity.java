package edu.temple.mci_res_lib.activities;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import edu.temple.mci_res_lib.R;
import edu.temple.mci_res_lib.utils.Constants;

public class CameraViewerActivity extends BaseReminderActivity {

    private static final Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
    private static final int CAMERA_REQUEST = 1888;

    private ImageView imageView;
    private String mCurrentPhotoPath = "";
    private Uri mCurrentPhotoURI;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_viewer);
        Log.i(Constants.LOG_TAG, "LAUNCHING CAMERA VIEW ACTIVITY\n\n");

        final Button closeButton = findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { finish(); }
        });
        imageView = findViewById(R.id.imageViewer);

        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            mCurrentPhotoURI = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, getPhotoValues());
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCurrentPhotoURI);
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST) {
            Log.d(Constants.LOG_TAG, "RECEIVED CAMERA REQUEST RESULT.  Result code (ok = -1, cancelled = 0): " + resultCode);
            if (resultCode == Activity.RESULT_OK) {
                String[] projection = { MediaStore.Images.Media.DATA };
                Cursor cursor = getContentResolver().query(mCurrentPhotoURI, projection, null, null, null);
                int data_column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();

                mCurrentPhotoPath = cursor.getString(data_column_index);
                File imgFile = new  File(mCurrentPhotoPath);
                if(imgFile.exists()){
                    Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                    imageView.setImageBitmap(myBitmap);
                } else {
                    Log.i(Constants.LOG_TAG, "Could not display current photo from file.  Displaying default");
                }

                galleryAddPic();
                removeOutstandingAlarm(false);
                Log.i(Constants.LOG_TAG, "Alarm acknowledgement complete!");
            }
            else if (resultCode == Activity.RESULT_CANCELED)
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
        }
    }

    private ContentValues getPhotoValues() {
        ContentValues photoValues = new ContentValues();
        photoValues.put(MediaStore.Images.Media.TITLE, "MCIReminders_"
                + (new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date())) + ".jpg");
        photoValues.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        photoValues.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        return photoValues;
    }

    private void galleryAddPic() {
        Log.i(Constants.LOG_TAG, "Attempting to register image file path: " + mCurrentPhotoPath
            + " with device gallery");
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri contentUri = Uri.fromFile(new File(mCurrentPhotoPath));
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }

}