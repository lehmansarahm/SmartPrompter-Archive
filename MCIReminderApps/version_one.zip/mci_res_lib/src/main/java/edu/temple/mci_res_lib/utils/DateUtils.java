package edu.temple.mci_res_lib.utils;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

    private static final String AM = "am";
    private static final String PM = "pm";

    private static final String DISPLAY_FORMAT = "MM/dd/yyyy hh:mm a";
    private static final String DISPLAY_FORMAT_FILE = "MM.dd.yyyy_hh.mm_a";
    private static final String TWENTY_FOUR_HR_FORMAT = "HH:mm";

    public static Calendar getReminderTime() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.MINUTE, 1);
        return cal;
    }

    public static String getCurrentDateTimeWithFileFormat() {
        SimpleDateFormat sdf = new SimpleDateFormat(DISPLAY_FORMAT_FILE);
        return sdf.format(new Date());
    }

    public static String getDisplayString(Calendar date) {
        SimpleDateFormat sdf = new SimpleDateFormat(DISPLAY_FORMAT);
        return sdf.format(date.getTime());
    }

    public static boolean hasDateTimePassed(String dateTime, boolean hasDisplayFormat) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DISPLAY_FORMAT);
        Calendar compDate;

        if (hasDisplayFormat) {
            compDate = Calendar.getInstance();
            compDate.setTime(sdf.parse(dateTime));
        }
        else compDate = parseTimeString(dateTime, false);

        return hasDateTimePassed(compDate);
    }

    public static Calendar parseTimeString(String dateTime, boolean forceFuture) throws ParseException {
        dateTime = dateTime.toLowerCase();
        if (dateTime.contains(AM))
            return parseTwelveHrTime(dateTime, false, forceFuture);
        else if (dateTime.contains(PM))
            return parseTwelveHrTime(dateTime, true, forceFuture);
        else return parseTwentyFourHrTime(dateTime, forceFuture);
    }

    private static Calendar parseTwelveHrTime(String dateTime, boolean isPm, boolean forceFuture) throws ParseException {
        dateTime = dateTime.substring(0, dateTime.indexOf((isPm) ? PM : AM)).trim();
        Calendar newDate = parseTwentyFourHrTime(dateTime, forceFuture);
        if (hasDateTimePassed(newDate) && forceFuture) newDate.add(Calendar.HOUR_OF_DAY, 12);
        return newDate;
    }

    private static Calendar parseTwentyFourHrTime(String dateTime, boolean forceFuture) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(TWENTY_FOUR_HR_FORMAT);
        Calendar tempDate = Calendar.getInstance();
        tempDate.setTime(sdf.parse(dateTime.trim()));

        Calendar newDate = Calendar.getInstance();
        newDate.setTimeInMillis(System.currentTimeMillis());
        newDate.set(Calendar.HOUR_OF_DAY, tempDate.get(Calendar.HOUR_OF_DAY));
        newDate.set(Calendar.MINUTE, tempDate.get(Calendar.MINUTE));
        newDate.set(Calendar.SECOND, 0);
        newDate.set(Calendar.MILLISECOND, 0);

        if (hasDateTimePassed(newDate) && forceFuture) newDate.add(Calendar.HOUR_OF_DAY, 12);
        return newDate;
    }

    private static boolean hasDateTimePassed(Calendar compDate) {
        SimpleDateFormat sdf = new SimpleDateFormat(DISPLAY_FORMAT);
        Date now = Calendar.getInstance().getTime();

        boolean hasTimePassed = now.after(compDate.getTime());
        Log.d(Constants.LOG_TAG, "Comparing dates ... now: " + sdf.format(now)
                + ", then: " + sdf.format(compDate.getTime())
                + "\n... Is now after then? " + (hasTimePassed ? "Yes" : "No"));
        return hasTimePassed;
    }

}