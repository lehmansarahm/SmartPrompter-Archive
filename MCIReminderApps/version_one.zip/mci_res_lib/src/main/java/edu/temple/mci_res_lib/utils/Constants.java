package edu.temple.mci_res_lib.utils;

public class Constants {

    final public static String LOG_TAG = "MCIReminderPrototypes";
    final public static String PREF_FILE_NAME = "MCIRemPrefs";

    final public static String PROJECT_NAME = "MCIReminders";
    final public static String PACKAGE_NAME = "edu.temple.mci_res_lib";
    final public static String FRIENDLY_PACKAGE_NAME = "edu.temple.mcireminderapps";

    final public static int REMINDER_ID = 3456;
    final public static String REMINDER_TITLE = "MCI Reminder";
    final public static String ALERT_TEXT = "Time to perform your task!";
    final public static String INTERVAL_TEXT = (ALERT_TEXT + "  Interval Alert #");

    final public static int MILLISEC_SEC = 1000 * 1;            // 1000 milli's in a sec
    final public static int MILLISEC_MIN = MILLISEC_SEC * 60;   // 1000 milli's in a sec, 60 sec's in a min
    final public static int MILLISEC_HOUR = MILLISEC_MIN * 60;  // 1000 milli's in a sec, 60 sec's in a min, 60 min's in an hour
    final public static int MIN_HOURS = 60 * 1;                 // 60 sec's in an hour

    final public static long DEFAULT_RINGTONE_TIME_MS = (MILLISEC_SEC * 10);    // play for 5 sec

    final public static int OUTSTANDING_ALARM_LIMIT = 4;

    final public static int PERMISSION_FLAG_CAMERA = 150;
    final public static int PERMISSION_FLAG_READ_EXTERNAL_STORAGE = 151;
    final public static int PERMISSION_FLAG_WRITE_EXTERNAL_STORAGE = 152;

}
