package edu.temple.mci_res_lib.managers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import edu.temple.mci_res_lib.utils.Constants;
import edu.temple.mci_res_lib.utils.DateUtils;

public class MCIPreferenceManager {

    public static final String REMINDER_COUNT = "reminderCount";
    public static final String REMINDER_TIMES = "reminderTimes";
    public static final String EXECUTION_MODE = "executionMode";
    public static final String OUTSTANDING_ALARM_COUNT = "outstandingAlarmCount";

    public static SchedulePrefs getSchedulePrefs(Context context, Intent intent) {
        Log.i(Constants.LOG_TAG, "Attempting to retrieve previous scheduling preferences.");
        SharedPreferences sharedPrefs = context.getSharedPreferences(Constants.PREF_FILE_NAME, Context.MODE_PRIVATE);
        SchedulePrefs prefs;

        // first, attempt to get schedule from shared preferences
        if (sharedPrefs != null) {
            Log.i(Constants.LOG_TAG, "Prefs file was not null.  Attempting to restore values.");
            prefs = populateFromSharedPrefs(sharedPrefs);
            if (prefs.executionMode != SchedulePrefs.EXEC_MODES.None) {
                Log.i(Constants.LOG_TAG, "Values successfully retrieved from the preference file.  Continuing program.");
                return prefs;
            }
            else Log.i(Constants.LOG_TAG, "No valid data in the preferences file.  Attempting to retrieve data from the activity intent.");
        }

        // if that doesn't work, attempt to get schedule from intent
        prefs = populateFromIntent(intent);
        Log.i(Constants.LOG_TAG, "Data retrieved from activity intent.  Current reminder count: " + prefs.reminderCount);
        return prefs;
    }

    public static void verifySchedulePrefs(Context context, SchedulePrefs prefs) {
        String alarmTime = "";
        if (prefs.reminderCount != 0) {
            try {
                boolean allAlarmsExpired = true;
                for (int i = 0; i < prefs.reminderTimes.size(); i++) {
                    alarmTime = prefs.reminderTimes.get(i);
                    boolean isCurrentAlarmExpired = DateUtils.hasDateTimePassed(alarmTime, true);
                    allAlarmsExpired &= isCurrentAlarmExpired;
                }

                if (allAlarmsExpired && prefs.outstandingAlarmCount == 0) {
                    Log.d(Constants.LOG_TAG, "All currently scheduled alarms have passed.  Clearing storage.");
                    prefs.reminderCount = 0;
                    prefs.reminderTimes = new ArrayList<>();
                }
            } catch (ParseException ex) {
                Log.e(Constants.LOG_TAG, "Could not verify schedule preferences.  "
                        + "Unable to parse selected alarm time: " + alarmTime);
            }
        }
        else prefs.reminderTimes = new ArrayList<>();
        saveSchedulePrefs(context, prefs); // save any changes that may have arisen
    }

    public static void saveSchedulePrefs(Context context, Intent intent) {
        saveSchedulePrefs(context, populateFromIntent(intent));
    }

    public static void saveSchedulePrefs(Context context, SchedulePrefs prefs) {
        SharedPreferences sharedPrefs = context.getSharedPreferences(Constants.PREF_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();

        editor.putInt(REMINDER_COUNT, prefs.reminderCount);
        editor.putInt(OUTSTANDING_ALARM_COUNT, prefs.outstandingAlarmCount);
        editor.putString(EXECUTION_MODE, prefs.executionMode.toString());

        if (prefs.reminderTimes == null) prefs.reminderTimes = new ArrayList<>();
        editor.putStringSet(REMINDER_TIMES, new HashSet<>(prefs.reminderTimes));

        Log.d(Constants.LOG_TAG, prefs.toString());
        editor.commit();
    }

    private static SchedulePrefs populateFromIntent(Intent intent) {
        SchedulePrefs prefs = new SchedulePrefs();
        prefs.reminderCount = intent.getIntExtra(REMINDER_COUNT, 0);                // default val = 0
        prefs.outstandingAlarmCount = intent.getIntExtra(OUTSTANDING_ALARM_COUNT, 0);   // def. val = 0

        prefs.reminderTimes = intent.getStringArrayListExtra(REMINDER_TIMES);
        if (prefs.reminderTimes == null) prefs.reminderTimes = new ArrayList<>();

        String execMode = intent.getStringExtra(EXECUTION_MODE);
        prefs.executionMode = (execMode != null && !execMode.isEmpty())
            ? SchedulePrefs.EXEC_MODES.valueOf(execMode)
            : SchedulePrefs.EXEC_MODES.None;

        Log.d(Constants.LOG_TAG, prefs.toString());
        return prefs;
    }

    private static SchedulePrefs populateFromSharedPrefs(SharedPreferences sharedPrefs) {
        SchedulePrefs prefs = new SchedulePrefs();
        Set<String> tempSet = new HashSet<>();

        prefs.reminderCount = sharedPrefs.getInt(REMINDER_COUNT, 0);
        prefs.reminderTimes = new ArrayList(sharedPrefs.getStringSet(REMINDER_TIMES, tempSet));
        prefs.outstandingAlarmCount = sharedPrefs.getInt(OUTSTANDING_ALARM_COUNT, 0);
        Log.d(Constants.LOG_TAG, "Retrieving outstanding alarm status... any missed alarms? " + prefs.hasMissedAlarms());

        prefs.executionMode = SchedulePrefs.EXEC_MODES.valueOf(sharedPrefs.getString(EXECUTION_MODE, "None"));
        Log.d(Constants.LOG_TAG, "Retrieving exec mode: " + prefs.executionMode.toString());
        return prefs;
    }

    public static class SchedulePrefs {
        public int reminderCount;
        public ArrayList<String> reminderTimes;
        public int outstandingAlarmCount;

        public enum EXEC_MODES { Basic, Advanced, None }
        public EXEC_MODES executionMode;

        public boolean hasMissedAlarms() { return (outstandingAlarmCount > 0); }

        public String toString() {
            return ("Current shared preference properties: "
                    + "\n... reminder count: " + reminderCount
                    + "\n... reminder times: " + android.text.TextUtils.join(", ", reminderTimes)
                    + "\n... outstanding alarm reminder count: " + outstandingAlarmCount
                    + "\n... exec mode: " + executionMode.toString());
        }
    }

}
