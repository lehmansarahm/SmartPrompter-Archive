package edu.temple.mci_res_lib.providers;

import android.support.v4.content.FileProvider;

public class ImageProvider extends FileProvider {

    public static final String AUTHORITY = "edu.temple.mci_res_lib.providers.ImageProvider";

}